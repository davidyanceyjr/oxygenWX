# Codex Prompt 01 — Apply Approved Theme-Pack Governance

Run this prompt only after the maintainer has approved the governance changes produced by Prompt 00.

Do not modify production Kotlin/Java/resources. Do not copy staged source. Do not change
`.codex/current.md` manually.

Read the same authority documents and proposals again. Re-check `git status --short` and
`git rev-parse HEAD`. Preserve unrelated local changes; never reset, checkout, or overwrite them.

Apply only the approved authority/document changes:

- the minimal required `docs/SPECIFICATION.md` amendment;
- the corresponding `docs/OXYGEN_UI_SPECIFICATION_ADOPTED.md` amendment;
- the approved bounded entries/wording in `docs/ROADMAP.md`;
- only architecture wording that is appropriate for an approved target versus already-implemented
  behavior. Do not falsely document unimplemented production code as present.

Do not mark an implementation roadmap item DONE or ACTIVE. The first new theme-pack item should
remain NEXT/PLANNED according to the approved roadmap structure.

After edits:

1. run `python scripts/dev.py workflow`;
2. run `python scripts/dev.py contract` if it is appropriate for documentation changes;
3. run `git diff --check`;
4. inspect the complete diff for semantic scope creep;
5. report exactly which authority clauses changed and why.

Stop. Do not start the first implementation cycle in this prompt. The maintainer reviews/commits
this authority diff before implementation begins.

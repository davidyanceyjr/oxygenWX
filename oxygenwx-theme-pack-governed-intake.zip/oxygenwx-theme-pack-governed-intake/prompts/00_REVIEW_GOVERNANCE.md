# Codex Prompt 00 — Review Theme-Pack Governance Only

You are in the root of the oxygenWX repository. This is a **read-only governance review**.
Do not edit, create, delete, move, or format repository files. Do not start or activate a
`.codex` cycle. Do not touch production code.

Read in repository authority order:

1. `docs/SPECIFICATION.md`
2. `docs/OXYGEN_UI_SPECIFICATION_ADOPTED.md`
3. `docs/ARCHITECTURE.md`
4. `docs/ROADMAP.md`
5. `.codex/current.md`
6. `AGENTS.md`
7. `docs/CODEX.md`

Then read:

- `oxygenwx-theme-pack-governed-intake/proposals/SPECIFICATION_AMENDMENT.md`
- `oxygenwx-theme-pack-governed-intake/proposals/UI_SPEC_AMENDMENT.md`
- `oxygenwx-theme-pack-governed-intake/proposals/ROADMAP_AMENDMENT.md`
- `oxygenwx-theme-pack-governed-intake/proposals/COMPONENT_CONTRACT.md`
- `oxygenwx-theme-pack-governed-intake/proposals/QUALITY_GATES.md`
- `oxygenwx-theme-pack-governed-intake/metadata/base.json`

Run only non-mutating inspection commands as needed, including `git status --short`,
`git rev-parse HEAD`, and `python scripts/dev.py workflow` if it does not modify tracked files.

Tasks:

1. Determine whether the five-theme production replacement requires a specification amendment.
   Cite the exact current clauses that make it necessary or unnecessary.
2. Determine which adopted UI-spec clauses must change and which invariants must remain verbatim.
3. Review the proposed R0.12–R0.17A roadmap slicing against the repository's 45% context-budget
   rule and dependency order. Split or reposition slices if needed; do not combine them.
4. Produce a concise proposed diff plan for the authoritative documents. Do not apply it.
5. Identify any conflicts between the proposed theme pack and current architecture/accessibility/
   navigation/data contracts.
6. Identify any repository drift from the base metadata and explain how that changes the proposal.

Stop after presenting the governance review and proposed authority changes. Await maintainer
approval before any file modification.

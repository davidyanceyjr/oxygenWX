# oxygenWX Theme Pack — Governed Intake Package

This package is intentionally **non-invasive when unzipped**.

It does not overwrite:

- `docs/SPECIFICATION.md`
- `docs/OXYGEN_UI_SPECIFICATION_ADOPTED.md`
- `docs/ROADMAP.md`
- `.codex/current.md`
- anything under `app/`

That is deliberate. The oxygenWX repository requires work to enter through its
specification/roadmap/Codex-cycle process before production code changes.

## Why this package exists

The requested product decision is to replace the current Theme B sketch UI with a
production theme system based on five built-in personalities:

- Atmospheric
- Glass
- Minimal OLED
- Instrument
- Terminal

This is not merely a color change. The current product specification names a different
built-in theme set and the adopted UI specification names Theme B as the selected visual
direction. Therefore this work requires an explicit authority update before implementation.

## Safe sequence

1. Run `prompts/00_REVIEW_GOVERNANCE.md`. It must not edit files.
2. Review/approve the proposed specification/UI-spec/roadmap change.
3. Run `prompts/01_APPLY_APPROVED_GOVERNANCE.md` only after approval.
4. Review/commit the authority-document diff.
5. Run `prompts/02_IMPLEMENT_NEXT_THEME_SLICE.md` once per roadmap slice. Do not ask
   Codex to implement the whole theme replacement in one cycle.

## Contents

- `proposals/` — exact product/UI/roadmap intent for review.
- `reference-assets/` — full art sheets, extracted references, SVGs and manifests.
- `theme-tokens/` — proposed semantic token catalogs.
- `staged-production/` — candidate implementation material split by roadmap slice;
  never copied wholesale.
- `metadata/` — base revision and repository file hashes used when this package was built.

## Base revision

Prepared against:

`7e63abad6344f8c1d82e6bfd71590782af9c23a1`

If repository HEAD or authority documents have changed, Codex must rebase the proposal onto
current authority rather than force-applying stale text.

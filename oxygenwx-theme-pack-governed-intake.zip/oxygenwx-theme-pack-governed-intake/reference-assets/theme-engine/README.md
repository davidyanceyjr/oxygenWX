# Theme Engine Design Assets

These assets are design/reference material for the production five-theme system. Full art boards and extracted PNGs remain under `docs/` so they are not packaged into the Android application by default. Runtime vectors live under `app/src/main/res/drawable/`.

The extracted directories include section crops, theme phone crops, and individual icon crops from the Glass and Instrument sheets. The JSON manifest in this directory enumerates the package.

# Proposed `docs/SPECIFICATION.md` Amendment

## Why a specification amendment is required

The current specification states that 1.0 targets **Oxygen, Paper, and Terminal** built-in
themes. The requested production UI instead defines **Atmospheric, Glass, Minimal OLED,
Instrument, and Terminal** as the built-in theme family. That is a product-scope decision,
not an implementation detail.

## Minimal intended changes

### Header

Advance the draft version/date only if that matches the repository's normal governance
practice for approved specification changes.

### Section 3.5 — Units and appearance

Replace only the built-in-theme bullet with:

> - Atmospheric, Glass, Minimal OLED, Instrument, and Terminal built-in themes;

Retain unchanged:

> - Standard and High contrast, independent of theme;
> - Standard and Simple layout presets;
> - Off, Subtle, and Full effects levels, with Off required to remain opaque, static, and complete.

Add immediately after the appearance target list:

> The built-in themes are alternate presentations of the same weather and navigation
> semantics. They may vary palette, typography, spacing/density, surface treatment,
> weather-mark treatment, procedural background treatment, and presentation motion. They
> must not change forecast values, chronology, provenance, missing-data behavior, official
> alert meaning, page semantics, or accessibility meaning. Theme selection resolves through
> a semantic appearance boundary before reusable Compose components render it.

### Section 13 — non-goals

Retain `downloadable/community themes` as a non-goal. The five built-in themes do not imply
a downloadable theme/plugin system.

## Explicit non-changes

Do not alter provider strategy, weather semantics, units, alerts, location behavior,
forecast horizons, cache semantics, or release safety requirements as part of this
amendment.

# Proposed `docs/OXYGEN_UI_SPECIFICATION_ADOPTED.md` Amendment

## Product decision

The existing Theme B implementation becomes a **historical sketch/baseline**, not the
production visual acceptance target. The production visual system is the five-theme
"One App. Many Personalities" system.

## Preserve these invariants unchanged

- Standard Home remains `Now -> Hourly -> Daily -> Details`.
- The outer Home pager remains the sole global horizontal-swipe owner.
- Hourly remains six real chronological entries per visible window.
- Daily remains five real chronological entries per visible window.
- Earlier/Later/date controls remain explicit.
- Details keeps provider-normalized, derived, and historical groups distinct.
- Important weather facts remain visible text with meaningful semantics.
- Effects Off remains opaque, static, and complete.
- Reusable components receive presentation models/semantic callbacks and resolved visual
  roles, not provider DTOs, repositories, or raw theme IDs.

## Replace the selected visual direction

Replace the current Theme B selected-direction section with an approved production theme
system section naming:

1. **Atmospheric** — immersive procedural weather field, low container emphasis.
2. **Glass** — restrained translucent/layered surfaces over a procedural atmosphere.
3. **Minimal OLED** — black-first, low-decoration, typography/data dominant.
4. **Instrument** — technical monitor/instrument-panel treatment with bounded data gauges.
5. **Terminal** — monospace, flat, console-like data presentation.

Atmospheric is the proposed initial default until persisted theme preference exists.

## Reference-art rule

Adopt the local theme-pack boards only as design/component references. Explicitly state:

- do not paste full art-board screenshots into runtime UI;
- do not invent weather data to fill an art-board composition;
- prefer semantic Compose components, procedural drawing, and vectors;
- Glass is a local production theme and must not be confused with the deprecated upstream
  dark-glass/gold dashboard examples;
- where an image conflicts with product/accessibility/navigation/data semantics, the written
  specification wins.

## Theme resolver contract

Retain and strengthen the existing conceptual contract:

```text
Theme + contrast + effects + layout + system motion policy
    -> resolved semantic appearance
    -> reusable Compose components
```

No component should branch on a raw theme identity to change meteorological or navigation
meaning. Theme-specific visuals should be represented by semantic render-style values
(surface style, background style, hero style, weather-mark style, density/geometry, etc.).

## Historical Theme B text

Move the current Theme B implementation description into a clearly marked historical/current
implementation baseline paragraph. Do not present it as the new acceptance target once this
amendment is approved.

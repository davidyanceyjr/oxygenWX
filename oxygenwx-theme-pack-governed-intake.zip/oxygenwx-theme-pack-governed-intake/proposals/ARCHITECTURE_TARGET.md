# Theme Engine Architecture Target

This is a target for later architecture documentation; it is not authority until the relevant
roadmap slice is implemented and the repository docs are updated.

```text
HomePresentation
      |
      +------------------------------+
      |                              |
      v                              v
Home interaction state       Appearance selection
(pager/windows)              theme/contrast/effects/layout
      |                              |
      +--------------+---------------+
                     v
              Semantic resolver
                     |
              ResolvedAppearance
                     |
         +-----------+------------+
         |                        |
         v                        v
Reusable production UI       Background renderer
         |
         v
Now -> Hourly -> Daily -> Details
```

Principles:

- no provider/repository/cache dependency in theme code;
- no parsing formatted strings to recover weather meaning;
- no raw theme ID inside meteorological/navigation logic;
- one production appearance system after cutover, not two parallel engines;
- theme assets are vectors/procedural primitives where practical;
- full art sheets remain documentation references, not runtime bitmaps;
- settings persistence remains a later R5 concern unless the roadmap is explicitly revised.

# Proposed `docs/ROADMAP.md` Amendment

This proposal intentionally splits the production UI replacement into bounded slices. Do not
collapse them into one large cycle.

## Add after R0.11

### R0.12 — Production theme-system authority — NEXT

Adopt the approved five-theme production visual system and project-local design references.
This is a documentation/design-authority slice only: reconcile the approved specification,
adopted UI specification, architecture target, and design-reference assets. Do not change
runtime Compose rendering in this slice.

Acceptance:

- approved theme names and semantic invariants are present in the authoritative documents;
- reference assets are stored under a project-owned design-reference path;
- the current Theme B renderer remains behaviorally unchanged;
- repository workflow/contract checks and `git diff --check` pass;
- the history record states that no production rendering changed.

### R0.13 — Production theme resolver foundation — PLANNED

Introduce the additive semantic theme identity/catalog/resolver behind the existing UI-local
appearance boundary. Add no page-composition changes and do not change the app entry point.
Preserve the current renderer as the default while resolver/catalog tests establish all five
built-in themes and Effects Off invariants.

### R0.14 — Production themed shared components — PLANNED

Add reusable theme-resolved surfaces, page identity/navigation styling, current-condition hero,
metric presentation, forecast entry/row treatment, Details groups, weather marks, and background
primitives. Keep them additive and unreferenced by the app entry point until page migration
slices. Components consume typed presentation data plus resolved semantic appearance only.

### R0.15 — Atmospheric Now and Hourly migration — PLANNED

Migrate Now and Hourly to the production component family using Atmospheric as the verification
theme. Preserve current facts, spoken summaries, six-entry windows, date jumps, Earlier/Later,
outer-pager ownership, Back behavior, and Effects Off completeness. Do not migrate Daily or
Details in this slice.

### R0.15A — Atmospheric Daily and Details migration — PLANNED

After R0.15, migrate Daily and Details to the same production component family. Preserve five-day
windows, Earlier/Later, source/freshness, provider-normalized/derived/historical separation, and
no invented chart inputs.

### R0.16 — Alternate production theme mappings — PLANNED

Add Glass, Minimal OLED, Instrument, and Terminal mappings through the same semantic resolver and
component family. Themes may vary visual treatment but not page structure, forecast membership,
weather meaning, provenance, or accessibility meaning. No component branches on raw theme IDs to
change data/navigation behavior.

### R0.17 — Production renderer cutover and sketch retirement — PLANNED

After the migrated pages and all theme mappings have installed evidence, make the production
renderer the application path. Remove or isolate obsolete Theme B sketch-only code only when the
final diff proves it is unused. Do not change provider/presentation semantics, add settings
persistence, or refetch weather because of theme selection.

### R0.17A — Cross-theme visual/accessibility verification — PLANNED

Verify the installed production renderer across the five built-in themes, compact phone, a
large-font case, RTL where chronology/navigation is affected, and Effects Off. Record exact
verified and unverified boundaries. This slice is evidence/repair only; it must not silently add
new product scope.

## Amend R5 theme work after R0.17 is complete

Replace the old theme-implementation intent with preference/settings work over the built-in
catalog:

### R5.2 — Persisted theme preference — PLANNED

Persist and restore one of Atmospheric, Glass, Minimal OLED, Instrument, or Terminal without
changing canonical weather/cache values or causing a forecast refetch.

### R5.2A — Theme selection settings surface — PLANNED

Expose the five built-in themes through accessible Appearance settings using the existing
resolver/catalog. Selection changes presentation only.

## Amend R6 wording when appropriate

Cross-theme appearance invariance should name the five production themes rather than the retired
Theme B/Paper theme set.

## Ordering note

This proposal deliberately places the renderer replacement in R0 because the repository describes
the current UI as a replacement-track candidate and the user has explicitly identified the current
Theme B UI as a sketch to be replaced before it becomes production visual authority. If the
maintainer prefers this work later in R5 instead, preserve the same bounded slice structure and
change only roadmap placement/dependencies.
